package ClubNautico;

public class Empleado {
    private int codigo;
    private String nombre;
    private DireccionTlf direccion;
    private DireccionTlf telefono;
    private String especialidad;
    private Zona numBarcosEncarga;
}
