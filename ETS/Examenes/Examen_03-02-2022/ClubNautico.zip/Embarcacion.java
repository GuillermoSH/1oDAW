package ClubNautico;

public class Embarcacion {
    private String matricula;
    private String nombre;
    private String tipo;
    private String dimensiones; //String considerando el formato 10x12x200
}
