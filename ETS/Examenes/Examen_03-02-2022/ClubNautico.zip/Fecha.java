package ClubNautico;

public class Fecha {
    private int dia;
    private int mes;
    private int anio;

    @Override
    public String toString(){
        return "Fecha en formato elegido";
    }
}
