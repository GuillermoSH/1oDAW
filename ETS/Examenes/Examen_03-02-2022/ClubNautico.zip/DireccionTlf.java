package ClubNautico;

public class DireccionTlf {
    private String direccion;
    private int telefono;
}
