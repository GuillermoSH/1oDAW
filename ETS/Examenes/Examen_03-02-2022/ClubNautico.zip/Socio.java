package ClubNautico;

public class Socio {
    private String nombre;
    private DireccionTlf direccion;
    private String DNI;
    private DireccionTlf telefono;
    private Fecha fechaIngreso;
}
