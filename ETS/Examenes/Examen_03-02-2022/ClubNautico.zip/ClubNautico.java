package ClubNautico;

import java.util.ArrayList;

public class ClubNautico{
    private ArrayList<Zona> zonas;
}