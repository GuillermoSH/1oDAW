package ClubNautico;

public class Zona {
    private char codigo;
    private String tipoBarcos;
    private int numBarcos;
    private double profundidad;
    private Amarre anchoAmarre;
}
