package ClubNautico;

public class Amarre {
    private int numero;
    private double lecContAgua;
    private double lecContLuz;
    private boolean servicioManten;
    private Fecha fechaAsignacion;
    private int ancho;
}
