package Ejercicio2;
import java.util.Scanner;
public class Main {
    public static void main(String []args){
        Scanner tec=new Scanner(System.in);
        double numero;

        System.out.print("Introduzca la cantidad de dolares que quiere convertir");
        numero=tec.nextDouble();
        f=new Finanzas(numero);
        Finanzas f;
        tec.close();

        System.out.println("Su cantidad de dinero ("+numero+") será igual a "+f.dolaresToEuros()+" euros y "+f.eurosToDolares()+" dolares.");
    }
    
    
}
