package Ejercicio2;

public class Finanzas {
    private double dolaresToEuros;
    private double euros=0;
    private double dolares=0;

    public Finanzas(){
        dolaresToEuros=1.36;
    }
    public Finanzas(double numero){
        dolaresToEuros=numero;
    }
    public double dolaresToEuros(){
        euros=dolares*dolaresToEuros;
        
        return dolares;
    }
    public double eurosToDolares(){
        dolares=euros/dolaresToEuros;
        
        return dolares;
    }
}
