package Ejercicio3;

public class MiNumero {
    private int numero;

    public MiNumero(int numero){
        this.numero=numero;
    }

    public int doble(){
        return numero*numero;
    }
    public int triple(){
        return numero*numero*numero;
    }
    public int cuadruple(){
        return numero*numero*numero*numero;
    }
}
