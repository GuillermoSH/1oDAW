package Ejercicio9;
import java.util.Scanner;
public class Peso {
    private double peso;

    public Peso(double peso, String unidad){
        this.peso=peso*conversionUnidad(unidad);
    }

    public double conversionUnidad(String unidad){
        double factor;
        
        switch(unidad){
            case "lb": factor = 0.453;
                break;
            case "li": factor = 14.59;
                break;
            case "oz": factor = 16/0.453;
                break;
            case "p": factor = 0.00155;
                break;
            case "k": factor = 1;
                break;
            case "g": factor = 1000;
                break;
            case "q": factor = 43.3;
                break;
            default: factor = 1; //por si se da el caso de que el usuario responde con otro valor de medida
        }
        return factor;
    }
    public double getLibras(){
        return peso/conversionUnidad("Lb");
    }
    public double getLingotes(){
        return peso/conversionUnidad("Li");
    }
    public double getPeso(String medida){
        return peso/conversionUnidad(medida);
    }
    public static void main(String []args){
        Peso objeto;

        System.out.print("Introduzca el peso que quiere convertir: ");
        Scanner tec = new Scanner(System.in);
        double peso=tec.nextDouble();

        System.out.print("\nIntroduzca la unidad de medida de su pesaje: ");
        tec.nextLine();
        String medida=tec.nextLine();
        tec.close();

        objeto = new Peso(peso,medida);

        System.out.println("\nPeso del objeto en Kilogramos: "+objeto.getPeso("k"));
        System.out.println("\n                   Libras: "+objeto.getPeso("lb"));
        System.out.println("\n                   Lingotes: "+objeto.getPeso("li"));
        System.out.println("\n                   Onzas: "+objeto.getPeso("oz"));
        System.out.println("\n                   Peniques: "+objeto.getPeso("p"));
        System.out.println("\n                   Gramos: "+objeto.getPeso("g"));
        System.out.println("\n                   Quintales: "+objeto.getPeso("q"));
    }
}
