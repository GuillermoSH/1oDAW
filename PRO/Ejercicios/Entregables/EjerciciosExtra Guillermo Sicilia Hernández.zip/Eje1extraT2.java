public static double hipotenusa(double cateto1, double cateto2){
	return cateto1*cateto1+cateto2*cateto2;
}