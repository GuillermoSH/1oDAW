public static int sumaNum(int suma){
	int numero;
	
	do{
		System.out.println("Introduzca un número (el 0 cierra la suma): ");
		java.util.Scanner tec=new java.util.Scanner(System.in);
		numero=tec.nextInt();

		suma+=numero;
	} while(numero!=0);
		return suma;
}