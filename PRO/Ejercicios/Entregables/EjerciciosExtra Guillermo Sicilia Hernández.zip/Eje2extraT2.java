public static boolean capicua(int numero, int numInvertido, int restante, int faltante){
	while(faltante!=0){
		restante=faltante%10;
		numInvertido=numInvertido*10+restante;
		faltante=faltante/10;
	}

	if(numInvertido==numero){
		return true;
	} else{
		return false;
	}
}