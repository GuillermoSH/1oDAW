public interface Prestable {
    void prestar();

    void devolver();

    boolean prestado();
}
