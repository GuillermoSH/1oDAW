public class Revista extends Publicacion {
    private int issn;
    private int codigo;

    public Revista(String titulo, int anio, int issn, int codigo) {
        super(titulo, anio);
        this.issn = issn;
        this.codigo = codigo;
    }

    public int getIssn() {
        return this.issn;
    }

    public int getCodigo() {
        return this.codigo;
    }

    @Override
    public String toString() {
        return "ISSN: " + this.isbn + ", título: " + this.titulo + ", año de publicación: " + this.anio;
    }
}
