public class Libro extends Publicacion {
    private int isbn;
    private boolean prestado;

    public Libro(String titulo, int anio, int isbn, boolean prestado) {
        super(titulo, anio);
        this.isbn = isbn;
        this.prestado = prestado;
    }

    public int getIsbn() {
        return isbn;
    }

    @Override
    public void prestar() {
        this.prestado = true;
    }

    @Override
    public void devolver() {
        this.prestado = false;
    }

    @Override
    public boolean prestado() {
        return this.prestado;
    }

    @Override
    public String toString() {
        if (prestado) {
            return "ISBN: " + this.isbn + ", título: " + this.titulo + ", año de publicación: " + this.anio + " (prestado)";
        } else {
            return "ISBN: " + this.isbn + ", título: " + this.titulo + ", año de publicación: " + this.anio + " (no prestado)";
        }
    }
}
